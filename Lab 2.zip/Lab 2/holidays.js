document.getElementById("submit-btn").addEventListener("click", () => {
  const countryCode = document.getElementById("country-code-input").value;

  const year = document.getElementById("year-input").value;

  const requestString = `https://date.nager.at/api/v3/PublicHolidays/${year}/${countryCode}`;

  fetch(requestString, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
    },
  })
    .then((response) => response.json())

    .then((data) => {
      const tableBody = document.getElementById("table-body");

      /* Clear previous results */
      tableBody.innerHTML = "";

      for (let element of data) {
        const row = tableBody.insertRow();

        const dateCell = row.insertCell();
        dateCell.textContent = element.date;

        const nameCell = row.insertCell();
        nameCell.textContent = element.name;

        const localNameCell = row.insertCell();
        localNameCell.textContent = element.localName;

        const countryCodeCell = row.insertCell();
        countryCodeCell.textContent = element.countryCode;

        const globalCell = row.insertCell();
        globalCell.textContent = element.global;
      }
    });
});
